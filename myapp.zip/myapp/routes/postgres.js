const { Pool, Client } = require('pg');

const pool = new Pool({
    host: 'localhost',
    database: 'Learning',
    user: 'postgres',
    password: 'admin',
    port: 5432
});

const postgresQueries = {
    getEmployeeDetails : function(){
        var result = pool.query('select * from employee');
        result.then(function(data){
            // console.log('Data', data);
            console.log('Record fetched successfully.');
        }).catch(function(err){
            console.log(err);
        });
        return result;
    },
    insertIntoEmployee : function(body){
        let age = parseInt(body.emp_age);
        console.log('date', body.emp_date);
        let query = `insert into employee(emp_name, emp_age, emp_date_of_joining) values ($1, $2, $3)`;
        let result = pool.query(query, [body.emp_name, age, body.emp_date]);
        result.then(function(data){
            console.log('Result of query', result);
        }, function(err){
            console.log(err)
        });
        return result;
    },
    deleteEmployee :  function(id){
        let query = `delete from employee where emp_id=$1`;
        return pool.query(query, [id]);
    }
};

module.exports = postgresQueries;