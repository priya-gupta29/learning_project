const { Pool, Client } = require('pg');

const pool = new Pool({
    host: 'localhost',
    database: 'learning_db',
    user: 'postgres',
    password: 'admin',
    port: 5432
});

// pool.query('select * from employee', (err, res)=>{
//     console.log(err, res);
//     pool.end();
// });

const postgresQueries = {
    getEmployeeDetails : function(){
        var result;
        pool.query('select * from employee', (err, res) => {
            result = res;
        });
        console.log('Hey', result);
        return result;
    },
    insertIntoEmployee : function(record){
        let query = `insert into employee values (${record.id}, ${record.name}, ${record.age}, ${record.date})`;
        let result = pool.query(query);
        return result;
    }
};

module.exports = postgresQueries;