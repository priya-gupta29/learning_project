var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'admin',
  database : 'world'
});
 
connection.connect();

const mySQLQueries = {
  getEmployeeDetails : function(){
      console.log('inside getEmployeeDetails')
    //   var result = connection.query('select * from employee');
    //   result.then(function(data){
    //     console.log('Data', data);
    //   }).catch(function(err){
    //       console.log(err);
    //   });
    let result;
    return new Promise((resolve, reject) => {
        connection.query('SELECT * from employee', function (error, results, fields) {
            if (error) return reject(error);
            console.log('The solution is: ', results);
            // result = results;
            resolve(results);

          });
    })
    
    //   return result;
  },
  insertIntoEmployee : function(body){
      let age = parseInt(body.emp_age);
      console.log('date', body.emp_date);
      var post = {name: body.emp_name, age: age, date: body.emp_date}
      let query = `insert into employee(emp_name, emp_age, emp_date_of_joining) values '${body.emp_name}', ${age}, '${body.emp_date}'`;
      return new Promise((resolve, reject) => {
        connection.query(query, function(err) {
            console.log(this.sql, err);
            if(err) return reject(err.message);
            resolve('Data inserted');
        });
      })
      
  }
};
 
//connection.end();

module.exports = mySQLQueries;