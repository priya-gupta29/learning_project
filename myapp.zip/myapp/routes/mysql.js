var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'admin',
  database : 'world'
});
 
connection.connect();

const mySQLQueries = {
  getEmployeeDetails : function(){
      var result;
      connection.query('select * from employee', function (error, results, fields) {
          if (error) throw error;
          console.log('The solution is: ', results);
      });
      console.log('Hey' , result);
      return result;
  },
  insertIntoEmployee : function(body){
      let age = parseInt(body.emp_age);
      console.log('date', body.emp_date);
      let query = `insert into employee(emp_name, emp_age, emp_date_of_joining) values ($1, $2, $3)`;
      let result = connection.query(query, [body.emp_name, age, body.emp_date]);
      result.then(function(data){
          console.log('Result of query', result);
      }, function(err){
          console.log(err)
      });
      return result;
  }
};
 
connection.end();

module.exports = mySQLQueries;