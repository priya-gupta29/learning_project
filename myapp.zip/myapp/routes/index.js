var express = require('express');
var router = express.Router();
const mysql = require('./mysql.js');
const postgres = require('./postgres.js');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/getEmployeeDetails/:dbname', function(req, res, next) {
  console.log('Database ',req.params.dbname);
  let result;
  if(req.params.dbname === 'postgres')
    result = postgres.getEmployeeDetails();
  else
    result = mysql.getEmployeeDetails();
  console.log('1', result);
  res.render('records', result);
});

module.exports = router;
