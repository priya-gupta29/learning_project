var express = require('express');
var router = express.Router();
// const mysql = require('./mysql.js');
const postgres = require('./postgres.js');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.post('/insertDataintoDb',function(req, res, next) {
  const { database } = req.body;
  if(database === 'postgres'){
    const result = postgres.insertIntoEmployee(req.body);
    result.then(function(data){
      res.send('Record Inserted into PostgreSQL database successfully!');
    }).catch(function(err){
      res.send('Something went wrong! Please contact System Administrator');
    });
  } else if(database === 'mysql'){
    const result = mysql.insertIntoEmployee(req.body);
    result.then(function(data){
      res.send('Record Inserted into MySQL database successfully!');
    }).catch(function(err){
      res.send('Something went wrong! Please contact System Administrator');
    });
  }
});

router.get('/getEmployeeDetails/:dbname',async function(req, res, next) {
  console.log('Database ',req.params.dbname);
  let result;
  let finalData = {};
  if(req.params.dbname === 'postgres'){
    result = await postgres.getEmployeeDetails();
    console.log(result.rows.length);
    finalData = result;
  }
  else
    result = mysql.getEmployeeDetails();
  console.log(finalData);
  res.render('records', finalData);
});

module.exports = router;
