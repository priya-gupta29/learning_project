const pool = require('./db.js');

function getDataFromDBPromise(queryText) {
    return new Promise((resolve, reject) => {
      pool.query(queryText, (err, res) => {
        if (err) {
          console.log('error occured while running query: ', queryText);
          console.log('error occured: ', err);
          reject(0);
        } else {
          resolve(res.rows);
        }
      });
    });
  }
  function getData() {
    const query = `select * from employee`;
    console.log(query);
    const dataPromise = getDataFromDBPromise(query);
    return dataPromise;
  }

  const data = getData();
  console.log(data);