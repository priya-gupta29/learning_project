"# Operations with DB" 

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>

The application consists of two api's to select from and to insert into the specified database. The project interacts with two database i.e. PostgreSQL and MySQL.
Below are the endpoints with detail:

1. https://localhost:3000
This is a insert based api. When user hits the above url, he/she will get a form to fill the required details to insert the record. The form consists of a dropdown from where he or she can choose to select the database in which record needs to be inserted. Once, user fills all the records and click submit, the record will get inserted and a success message would get displayed.

2. https://localhost:3000/getEmployeeDetails/{database_name}
This api is used to retrieve all data from the specified database. Database needs to be specified as a parameter to the get request. For exampple, if user needs to retrieve data from PostgreSQL, he/ she needs to hit url https://localhost:3000/getEmployeeDetails/postgres and if user needs to retrieve data from mysql database, hit url https://localhost:3000/getEmployeeDetails/mysql.


