const { Pool, Client } = require('pg');

const pool = new Pool({
    host: 'localhost',
    database: 'Learning',
    user: 'postgres',
    password: 'admin',
    port: 5432
});

const postgresQueries = {
    getEmployeeDetails : function(){
        var result = pool.query('select * from employee');
        result.then(function(data){
            console.log('Record fetched successfully.');
        }).catch(function(err){
            console.log(err);
        });
        return result;
    },
    insertIntoEmployee : function(body){
        let age = parseInt(body.emp_age);
        console.log('date', body.emp_date);
        let emp_id = body.emp_id;
        if(emp_id > 0){
            let emp_age = parseInt(body.emp_age);
            let query = `update employee set emp_name=$1, emp_age=$2, emp_date_of_joining=$3 where emp_id=$4`;
            return pool.query(query, [body.emp_name, body.emp_age, body.emp_date, emp_id]);
        }
        else{
            let query = `insert into employee(emp_name, emp_age, emp_date_of_joining) values ($1, $2, $3)`;
            return pool.query(query, [body.emp_name, age, body.emp_date]);
        }
    },
    deleteEmployee :  function(id){
        let query = `delete from employee where emp_id=$1`;
        return pool.query(query, [id]);
    },
    fetchEmployeeDetails : function(id){
        console.log('Fetching details', id);
        if(id>0){
            let query = `select * from employee where emp_id=$1`;
            return pool.query(query, [id]);
        }
    }
};

module.exports = postgresQueries;