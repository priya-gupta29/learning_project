var express = require('express');
var router = express.Router();
// const mysql = require('./mysql.js');
const postgres = require('./postgres.js');

/* GET home page with form */
router.get('/', function(req, res) {
    res.redirect('/insert');
});

router.get('/insert',async function(req, res, next) {
  let emp_id = req.query.id;
  console.log('Id------------', emp_id);
  let result = await postgres.fetchEmployeeDetails(emp_id);
  var data = {};
  if(result!==undefined){
    result = result.rows[0];
    var data = {
      emp_id: emp_id,
      emp_name: result.emp_name, 
      emp_age: result.emp_age,
      emp_date: result.emp_date_of_joining,
      db: 'PostgreSQL'
     };
   data.data = data;
  }
  res.render('index', data);
});

router.post('/deleteRecord',async function(req, res, next) {
  const result = await postgres.deleteEmployee(req.body.id);
  console.log(result);
  res.status(200).send({msg: 'Record deleted successfully!'});
});

router.post('/editRecord', async function(req, res, next){
  const result = await postgres.editEmployee(req.body.id);
  console.log(result);
  res.status(200).send({msg: 'Record updated successfully!'});
})

router.post('/insertDataIntoDb',async function(req, res, next) {
  const { database, emp_id } = req.body;
  if(database === 'postgres'){
    try{
      const result = await postgres.insertIntoEmployee(req.body);
      console.log(result);
      if(emp_id > 0){
        res.send('Record updated successfully.');
      } else{
        res.send('Record saved successfully');
      }
    }
    catch(error) {
      console.error(error);
      res.send('Something went wrong! Please contact System Administrator');
    }
  } else if(database === 'mysql'){
    const result = mysql.insertIntoEmployee(req.body);
    result.then(function(data){
      console.log(data);
      
      res.send('Record Inserted into MySQL database successfully!');
    }).catch(function(err){
      
      res.send(err.message);
    });
  }
});

router.get('/getEmployeeDetails/:dbname',async function(req, res, next) {
  console.log('Database ',req.params.dbname);
  let result = [];
  let finalData = {};
  if(req.params.dbname === 'postgres'){
    let { rows } = await postgres.getEmployeeDetails();
    console.log(rows);
    const temp  = rows.map(ele => {
      ele.emp_date_of_joining = new Date(ele.emp_date_of_joining).getDate();
    })
    console.log(temp);
    finalData.finalData = rows;
  }
  else if(req.params.dbname === 'mysql'){
    result = await mysql.getEmployeeDetails();
    console.log(result);
    finalData.finalData = result;

  }
  res.status(200).send(finalData);
  
});

module.exports = router;
